package com.example.otel;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    private final OrderMetrics orderMetrics;

    public OrderController(OrderMetrics orderMetrics) {
        this.orderMetrics = orderMetrics;
    }

    @PostMapping("/orders")
    public String createOrder(@RequestParam(name = "item", defaultValue = "demo") String item) {
        orderMetrics.incrementOrdersCreated();
        return "Order created for item: " + item;
    }

    @GetMapping("/test-error")
    public String testError() {
        throw new RuntimeException("Simulated test error from /test-error endpoint");
    }
}
