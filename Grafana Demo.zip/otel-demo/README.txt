Steps taken to create Application Error Rate panel on my grafana cloud account:

1. Add below two dependencies in your spring boot app:
a. spring-boot-starter-actuator
b. micrometer-registry-prometheus (to expose /actuator/prometheus endpoint)

2. Configure application.yaml
management:
  endpoints:
    web:
      exposure:
        include: health,info,prometheus,metrics
 metrics:
    tags:
      application: otel-demo-spring

3. Create grafana alloy docker container (Attached alloy-config.alloy: alloy-config.alloy)
docker run -d `
  -p 4317:4317 -p 4318:4318 `
  -v "${PWD}\alloy-config.alloy:/etc/alloy/config.alloy" `
  --name alloy `
  grafana/alloy:latest

4. To get OTLP, Prometheus endpoints, username, password - create free account on grafana cloud

This setup is required to push metrics and build panels for Grafana Dasboards.

Grafana alloy with prometheus configuration (done in alloy config) scraps metrics like http_server_requests_seconds_count (required for app error rate) exposed at /actuator/prometheus endpoint and push them to grafana cloud prometheus backend.


------------------------------------------------------------------------------------

Success request: POST http://localhost:8080/orders
To generate error: GET http://localhost:8080/test-error

------------------------------------------------------------------------------------


PromQL Queries identified to build Panels on Grafana Dashboard :

// 2xx (OK/Accepted) Count
clamp_min(
  round(
    sum(
      increase(
        http_server_requests_seconds_count{
          status=~"2..",
          job="prometheus.scrape.actuator_app",
          uri!="/actuator/prometheus"
        }[$__range]
      )
    )
  ),
  0
)


// Application Error Rate (Time Series)
100 *
(
  sum(
    rate(
      http_server_requests_seconds_count{
        job="prometheus.scrape.actuator_app",
        status!~"2.."
      }[$__rate_interval]
    )
  )
/
  sum(
    rate(
      http_server_requests_seconds_count{
        job="prometheus.scrape.actuator_app",
        uri!="/actuator/prometheus"
      }[$__rate_interval]
    )
  )
)


// Application Error Rate (Stats)
100 *
(
  sum(
    increase(
      http_server_requests_seconds_count{
        job="prometheus.scrape.actuator_app",
        status!~"2..",
        uri!="/actuator/prometheus"
      }[$__range]
    )
  )
/
  sum(
    increase(
      http_server_requests_seconds_count{
        job="prometheus.scrape.actuator_app",
        uri!="/actuator/prometheus"
      }[$__range]
    )
  )
)



------------------------------------------------------------------------------------------------------------

